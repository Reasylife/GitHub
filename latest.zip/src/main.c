#include "version.h"
#include <studio.h>
int
	main()
{
	pritf("hello,word.\n");
	pritf("version: %s.\n",_VERSION);
	return 0;
}
